# TI2_2023
Repositório para a disciplina de Trabalho Interdisciplinar II: BackEnd. Contém os exercícios individuais.
