/*
 * Trabalho Interdisciplinar II: BackEnd
 * Exercício 01 - Integração Eclipse e GitHub
 * 
 * Catarina F. M. Castro
 * */

package pacote;

import java.util.*;

public class SomarNumeros {
	
	// Declaracao de Scanner
	public static Scanner sc = new Scanner(System.in);
	
	public static void main (String args[]){
		//Declaracao de variaveis
		int num1, num2, soma;
		
		//Leituras
		System.out.println("Digite um número");
		num1 = sc.nextInt();
		
		System.out.println("Digite outro número");
		num2 = sc.nextInt();
		
		//Somar
		soma = num1 + num2;
		
		//Mostrar na tela
		System.out.println("Soma:" + soma);
	}
}
